package com.top.deploy;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DeployApplicationTests {

	@Test
	void contextLoads() {
	}

}
